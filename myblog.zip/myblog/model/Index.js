var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/myblog');
console.log("成功连接数据库");


exports.Article = require("./Article");
exports.User = require("./User");
exports.Link = require("./Link");
