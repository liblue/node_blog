var mongoose = require('mongoose');

var Link = mongoose.model('Link', {
    username: String ,
    password: String
});


module.exports = Link;
