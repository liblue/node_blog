
module.exports = Article;


var mongoose = require('mongoose');

var Article = mongoose.model('Article', {
    username: String ,
    password: String
});


module.exports = Article;
