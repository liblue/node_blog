var formidable = require('formidable')
var bodyParser = require('body-parser')
var User = require("../model").User;
var Article = require("../model").Article;
var Link = require("../model").Link;
var session = require('express-session')
var checkLogin = require('../middlewares/check').checkLogin;

module.exports = function (app) {

  app.get('/',   function (req, res) {
    res.redirect(303,'/record')//跳转到record路由， use record  已经引用
  })

  app.get('/branch', function (req, res) {
    res.render('branch')
  })
   app.get('/all_record', function (req, res) {
    res.render('all_record')
  })
   app.get('/about', function (req, res) {
    res.render('about')
  })
   app.get('/login', function (req, res) {
    res.render('login')
  })
   app.post('/login', function (req, res) {


   var  username = req.fields.name;
   var  password = req.fields.password;
  //   try {
  //   if (!name.length) {
  //     throw new Error('请填写用户名')
  //   }
  //   if (!password.length) {
  //     throw new Error('请填写密码')
  //   }
  // } catch (e) {
  //   req.flash('error', e.message)
  //   return res.redirect('back')
  // }
    User.findOne({username:username,password:password},function(err,user){
        if(user){

            req.session.user = user;

            res.redirect(303,'/record')
            // session
        }else{


            res.render("login",{error:true});

        }
    })


  })

app.get('/logout', function(req, res){


    req.session.destroy();
     res.redirect(303,'/login')

});





     app.get('/register', checkLogin ,function(req, res){


       res.render('register')

});
  app.post('/register', function(req, res){
    var  username=req.fields.name;

    var password=req.fields.password;


   var user = new User({username:username,password:password});
        user.save();
   var article = new Article({username:username,password:password});
       article.save();
       var link = new Link({username:username,password:password});
       link.save();

      res.redirect(303,'/record')

});
/*

use 与get的区别  use(espress.router)相当于资源路由（体会），是使用某个文件  比如  use  record
引入record.js文件还可以访问 record/a   record/a/b   record.js里面有什么路由都可以用
这里use  的意思是use 某个文件 一定是某个存在的文件。

get 是路由  可以随便取  但不能变  比如about后面就不可以  about/a

*/


  app.use('/signin',  require('./signin'))
  app.use('/signout',require('./signout'))
  app.use('/record',require('./record'))
  app.use('/comments', require('./comments'))

}
