const express = require('express')
const router = express.Router()
var ejs = require('ejs');


const checkNotLogin = require('../middlewares/check').checkNotLogin
var data={
  name : 'webarn',
  sex : '男',
  content : '参数,可以更改'
};
// GET /signin 登录页

router.get('/', checkNotLogin, function (req, res, next) {
  res.render('login',data)
})
// POST /signin 用户登录
router.post('/', checkNotLogin, function (req, res, next) {
  res.send('登录')
})

module.exports = router
